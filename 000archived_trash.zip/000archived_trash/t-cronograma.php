<?php
/*Template Name: Pomo - Cronograma*/
?>
<?php get_header() ?>

<div class="content_nosidebar">
     
</div><!-- #content -->
	
<?php get_footer() ?>