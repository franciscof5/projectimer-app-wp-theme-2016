<?php
/*Template Name: Pomo - Entregas*/
?>
<?php get_header() ?>

<div class="content_nosidebar">
     
</div><!-- #content -->
	
<?php get_footer() ?>